// console.log(' Hola Todos ');


let c;
let f = 90;


// c = (f - 32) * (5 / 9);

c = f - 32;
c = c * (5 / 9);


// C a F
// C o F = K



console.log(c);