let gasolina = 3;

while (gasolina > 0) {

    console.log('Gasolina restante ' + gasolina);

    // gasolina = gasolina - 1;
    gasolina--;

}

console.log('Ya no tiene gasolina');